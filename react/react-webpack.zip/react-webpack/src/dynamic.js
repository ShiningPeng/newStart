export const a = 1;
export default function foo() {
  console.log(1);
}