import React from 'react';
import ReactDOM from 'react-dom';
// import xx from 'xxx.jpg';
import App from './App';

ReactDOM.render(<App />, document.getElementById('root'));